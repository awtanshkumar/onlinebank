package com.entity.layer2;

import java.util.List;

//import javax.management.Query;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

//import org.hibernate.query.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.entity.layer1.Fundtransfer;
//import com.lti.pojo.accNumber;
//import com.lti.pojo.from;
//import com.lti.pojo.select;
//import com.lti.pojo.t;


@Repository
public class FundTransferRepositoryImpl implements FundTransferRepository{
	
	@PersistenceContext
	private EntityManager em;
	
	
	@Override
	public void save(Fundtransfer fundtransfe) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int getTransactionId() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Transactional
	public List<Fundtransfer> getAllRecords(String accNumber) {
		
		Query query= em.createNativeQuery("select * from fundtransfer t where t.FROM_ACCNO="+accNumber+" or t.TO_ACCNO="+accNumber,
		
				Fundtransfer.class);

				List<Fundtransfer> items = query.getResultList(); 

			//List<fundTransfer> f=query.getResultList();
		                          //  select * from fundtransfer t where t.FROM_ACCNO=111 OR t.TO_ACCNO=111;
		
		
		//("getMiniStatement").setParameter("accNumber",accNumber)
		return items;
	}

	@Override
	public List<Fundtransfer> getTransactionBetweenDates(String fromDate, String toDate, String accountnumber) {
		// TODO Auto-generated method stub
		return null;
	}
	
	

}
