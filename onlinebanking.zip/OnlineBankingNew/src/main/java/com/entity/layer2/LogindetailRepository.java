package com.entity.layer2;

import java.util.List;


import com.entity.layer1.Logindetail;

public interface LogindetailRepository {
	void save(Logindetail login);
		public String getUserId();
		
		
		
		List<Logindetail> getUserByAccNumber(String accNumber);
		
		void resetPassword(String updatedPassword,String accountno);
		void resetTransactionPassword(String userId,String updatedPassword);
		
		
			}
