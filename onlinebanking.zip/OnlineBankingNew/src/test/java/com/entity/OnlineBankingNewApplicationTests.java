package com.entity;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.entity.layer1.Fundtransfer;
import com.entity.layer2.FundTransferRepository;
import com.entity.layer1.Logindetail;
import com.entity.layer2.LogindetailRepository;

@SpringBootTest
class OnlineBankingNewApplicationTests {
	
	@Autowired
	FundTransferRepository a;
	@Autowired
	LogindetailRepository b;
	

	@Test
	void contextLoads() {
		
		List<Fundtransfer> f=a.getAllRecords("111");
		
		for(Fundtransfer ab:f)
		{
			System.out.println(ab.getAmount());
		}
		
	}
	@Test
	void contextLoads1()
	{
		String f=b.getUserId();
		System.out.println (f);
	}
@Test	
void contextLoads3() {
		
		List<Logindetail> g=b.getUserByAccNumber("222");
		
		for(Logindetail ac:g)
		{
			System.out.println(ac.getUserid());
		}
}
@Test
void contextLoads4()
{
	b.resetPassword("aaa", "'111'");
}
@Test
void contextLoads5()
{
	b.resetTransactionPassword("'10001'", "'ak###1'");
}
}
